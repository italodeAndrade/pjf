public class Imobiliaria {
    //atributos de imobiliaria
    String CNPJ;
    String junta_cmr;
    double alv_funcion;
    String cntrt_locação;
    double saldo;
     
}
