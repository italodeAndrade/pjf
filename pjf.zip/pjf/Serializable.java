
public interface Serializable {
}

