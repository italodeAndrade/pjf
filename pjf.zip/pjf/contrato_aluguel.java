public interface contrato_aluguel {
    double calcularValorAluguel();
    String getDtInicAluguel();
    String getDtFnAluguel();
}

